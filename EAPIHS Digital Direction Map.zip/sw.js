const CACHE = 'EAPIHS-MAP-V151';
const CORE_ASSETS = [
  "./", "./index.html", "./manifest.json",
  "./assets/logo.png", "./assets/icon-192.png", "./assets/icon-512.png",
  "./assets/eapihs-2d-campus-plan.jpg", "./assets/eapihs-3d-campus.jpg",
  "./assets/eapihs-evacuation-plan.jpg"
];
self.addEventListener("install", event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE);
    await Promise.all(CORE_ASSETS.map(path => cache.add(path).catch(() => null)));
    await self.skipWaiting();
  })());
});
self.addEventListener("activate", event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key !== CACHE).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});
self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    try {
      const response = await fetch(request, { cache: "no-store" });
      if (response && response.ok) {
        const copy = response.clone();
        cache.put(request, copy).catch(() => {});
        if (request.mode === "navigate") cache.put("./index.html", response.clone()).catch(() => {});
      }
      return response;
    } catch (_) {
      const cached = await caches.match(request);
      if (cached) return cached;
      if (request.mode === "navigate") return (await caches.match("./index.html")) || (await caches.match("./")) || Response.error();
      return Response.error();
    }
  })());
});
